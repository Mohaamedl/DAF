---
title: Symmetry and tensors
keywords: docs
sidebar: sw_sidebar
permalink: symmetry.html
summary: Representation of space groups and coordinate systems
folder: documentation
mathjax: true
---


## Symmetry operators
## Space groups

