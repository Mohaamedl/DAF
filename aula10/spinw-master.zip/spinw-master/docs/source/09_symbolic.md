---
title: Symbolic calculation
keywords: docs
sidebar: sw_sidebar
permalink: symbolic.html
summary: Symbolic spin wave calculation mode
folder: documentation
mathjax: true
---

* defining a symbolic model
* analytical solution to the ground state
* solving and analysing spin wave spectrum