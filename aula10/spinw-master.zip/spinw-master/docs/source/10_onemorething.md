---
title: Usefull functions in neutron/x-ray scattering
keywords: docs
sidebar: sw_sidebar
permalink: onemorething.html
summary: List of usefull functions that are not directly connected to SpinW
folder: documentation
mathjax: true
---

* converters
* etc.