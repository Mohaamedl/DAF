---
title: Solvers
keywords: docs
sidebar: sw_sidebar
permalink: spinwave.html
summary: Solvers to calculate spin-spin correlation function
folder: documentation
mathjax: true
---

* linear spin wave solver
* spin-spin correlation function
* powder spectrum