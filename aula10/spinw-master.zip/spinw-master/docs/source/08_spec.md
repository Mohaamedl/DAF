---
title: Correlation function post processing and fitting
keywords: docs
sidebar: sw_sidebar
permalink: spec.html
summary: Post processing the spin-spin correlation function
folder: documentation
mathjax: true
---


* cross section calculation
* resolution convolution
* fitting spin wave spectrum