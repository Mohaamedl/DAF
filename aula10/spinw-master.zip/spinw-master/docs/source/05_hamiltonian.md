---
title: Spin Hamiltonian
keywords: docs
sidebar: sw_sidebar
permalink: hamiltonian.html
summary: Definition of the complete spin Hamiltonian
folder: documentation
mathjax: true
---

## General spin Hamiltonian
## Bonds
## General matrices
## Single ion properties
## Tensors
## Classical ground state