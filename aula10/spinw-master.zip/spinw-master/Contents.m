% SpinW
% Version 3.1 (unreleased) 29-Nov-2017
% 
