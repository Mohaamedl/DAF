%% sw properties

docDir = '~/spinwdoc_git/docs/';
imDir  = [docDir 'images/'];

plot(sw)
saveas(gcf,[imDir 'swclass1.png'])
close all


