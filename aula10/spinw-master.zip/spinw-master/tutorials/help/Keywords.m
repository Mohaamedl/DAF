%% Keywords

%%
% You can search for keywords below, that describe different topics. If you
% have a question, this is a good starting point to search.
% 
% <html><br></html>
% 
% *A, B, C*
% 
% <html><br></html>
% 
% atom.dat, bond, cif class, cif file, constraint function,
% coordinate system, crystal structure
%
% 
% <html><br></html>
% 
% *D, E, F*
% 
% <html><br></html>
% 
% exchange coupling 
%
% <html><br></html>
% 
% *G, H, I*
% 
% <html><br></html>
% 
% g-matrix, ion.dat, help, Horace
%
% 
% <html><br></html>
% 
% *J, K, L*
%
% 
% <html><br></html>
% 
% *M, N, O*
% 
% <html><br></html>
% 
% list of sw methods, long range order, magnetic field, magnetic structure
% 
% <html><br></html>
% 
% *P, Q, R*
% 
% <html><br></html>
% 
% plotting crystal structure, list of sw properties, powder spectrum 
% 
% <html><br></html>
% 
% *S, T, U*
% 
% <html><br></html>
% 
% simulated annealing, space group, spin, spin-spin correlation function,
% spin wave, symmetry.dat, sw class, temperature, twin, units
% 
% <html><br></html>
% 
% *V, W, X, Y, Z*
%