% package of mathematical functions
%
% The library contains basic mathematical functions that can be used by
% SpinW for defining instrumental resolution function, etc.
%
% ### Files
%   swfunc.gauss
%   swfunc.gaussfwhm
%   swfunc.lorfwhm
%   swfunc.pvoigt
%   swfunc.voigtfwhm
