function verInfo = version(obj)
% returns the version of SpinW
%
% ### Syntax
%
% `verInfo = version(obj)`
%

verInfo = obj.ver;

end