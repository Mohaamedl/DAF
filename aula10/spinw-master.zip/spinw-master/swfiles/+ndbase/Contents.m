% package for basic data analysis
%
% The library contains fundamental building blocks for a future data
% analysis library.
%
% ### Files
%   ndbase.histn
%   ndbase.lm
%   ndbase.pso
%   ndbase.simplex
%   ndbase.source
